# Head Pose Estimation 
## Data Preprocessing
Holds the scripts used to preprocess 300W-lp and BIWI datasets
## Training
In the Training folder you will find both the initial training Scripts where each file trains a number of backends 
## Testing
Holds Testing Scripts that has demo to try models